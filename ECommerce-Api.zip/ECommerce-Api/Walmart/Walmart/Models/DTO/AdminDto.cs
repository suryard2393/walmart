﻿namespace Walmart.Models.DTO
{
    public class AdminDto
    {

        public int AdminId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

    }
}
