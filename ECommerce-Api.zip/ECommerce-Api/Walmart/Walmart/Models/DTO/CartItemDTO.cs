﻿namespace Walmart.Models.DTO
{
    public class CartItemDTO
    {
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
    }
}