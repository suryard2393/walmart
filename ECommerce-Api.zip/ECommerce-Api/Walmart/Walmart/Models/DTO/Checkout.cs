﻿namespace Walmart.Models.DTO
{
    public class Checkout
    {
       
            public string ShippingAddress { get; set; }
            public string PaymentMode { get; set; } 

    }
}
