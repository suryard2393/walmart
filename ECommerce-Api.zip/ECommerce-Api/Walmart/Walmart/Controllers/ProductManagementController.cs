﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductManagementController : ControllerBase
    {
        private readonly IProductManagementRepository _productManagementRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<ProductManagementController> _logger;

        public ProductManagementController(IProductManagementRepository productManagementRepository, IMapper mapper, ILogger<ProductManagementController> logger)
        {
            _productManagementRepository = productManagementRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("Add Products")]
        public async Task<IActionResult> Create([FromBody] ProductManagementDTO productManagementRequest)
        {
            try
            {
                var newProduct = _mapper.Map<ProductManagement>(productManagementRequest);

                await _productManagementRepository.AddProductAsync(newProduct);

                var productResponse = _mapper.Map<ProductManagementDTO>(newProduct);

                return CreatedAtAction(nameof(GetById), new { id = newProduct.ProductId }, productResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding a new product.");
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "User,Admin")]
        [HttpGet("Search The Product")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var product = await _productManagementRepository.GetProductByIdAsync(id);
                if (product == null)
                {
                    return NotFound($"Product with ID {id} not found.");
                }

                var productDTO = _mapper.Map<ProductManagementDTO>(product);

                return Ok(productDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching the product by ID {ProductID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("Search By Name")]
        public async Task<IActionResult> GetByName(string Name)
        {
            try
            {
                var product = await _productManagementRepository.GetProductByNameAsync(Name);
                if (product == null)
                {
                    return NotFound($"Product with name {Name} not found.");
                }

                var productDTO = _mapper.Map<ProductManagementDTO>(product);

                return Ok(productDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching the product by name {ProductName}.", Name);
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "User,Admin")]
        [HttpGet("All Products")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var products = await _productManagementRepository.GetAllProductsAsync();

                var productDTOs = _mapper.Map<IEnumerable<ProductManagementDTO>>(products);

                return Ok(productDTOs);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching all products.");
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("Edit Product")]
        public async Task<IActionResult> Update(int id, [FromBody] ProductManagementDTO productManagementRequest)
        {
            try
            {
                var existingProduct = await _productManagementRepository.GetProductByIdAsync(id);
                if (existingProduct == null)
                {
                    return NotFound($"Product with ID {id} not found.");
                }

                _mapper.Map(productManagementRequest, existingProduct);

                await _productManagementRepository.UpdateProductAsync(existingProduct);

                return Ok(existingProduct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating the product with ID {ProductID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("Delete Product")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var product = await _productManagementRepository.GetProductByIdAsync(id);
                if (product == null)
                {
                    return NotFound($"Product with ID {id} not found.");
                }

                await _productManagementRepository.DeleteProductAsync(id);

                return Ok("Deleted Successfully!");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the product with ID {ProductID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
