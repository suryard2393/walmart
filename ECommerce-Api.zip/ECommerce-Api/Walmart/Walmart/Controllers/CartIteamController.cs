﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;

[Route("api/[controller]")]
[ApiController]
[Authorize(Roles = "User")]
public class CartItemController : ControllerBase
{
    private readonly ICartItemRepository _cartItemRepository;
    private readonly IMapper _mapper;
    private readonly ILogger<CartItemController> _logger;

    public CartItemController(ICartItemRepository cartItemRepository, IMapper mapper, ILogger<CartItemController> logger)
    {
        _cartItemRepository = cartItemRepository;
        _mapper = mapper;
        _logger = logger;
    }

    [HttpPost("Add Into Cart")]
    public async Task<IActionResult> Post([FromBody] CartItemDTO cartItemRequest)
    {
        try
        {
            var product = await _cartItemRepository.GetProductByIdAsync(cartItemRequest.ProductID);
            if (product == null)
            {
                return NotFound($"Product with ID {cartItemRequest.ProductID} not found.");
            }

            var user = await _cartItemRepository.GetUserByIdAsync(cartItemRequest.UserID);
            if (user == null)
            {
                return NotFound($"User with ID {cartItemRequest.UserID} not found.");
            }

            var totalPrice = cartItemRequest.Quantity * product.Price;

            var cartItem = _mapper.Map<CartItem>(cartItemRequest);
            cartItem.TotalPrice = totalPrice;
            cartItem.ProductManagement = product;
            cartItem.User = user;

            await _cartItemRepository.AddCartItemAsync(cartItem);

            var cartItemResponse = _mapper.Map<CartItemResponseDTO>(cartItem);

            return CreatedAtAction(nameof(Get), new { id = cartItem.CartItemID }, cartItemResponse);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while adding a cart item.");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("Your Cart")]
    public async Task<IActionResult> GetByUserId(int userId)
    {
        try
        {
            var cartItems = await _cartItemRepository.GetCartItemsByUserIdAsync(userId);
            if (cartItems == null || !cartItems.Any())
            {
                return NotFound($"No cart items found for User ID {userId}.");
            }

            var cartItemDetailsDTOs = _mapper.Map<IEnumerable<CartItemDetailsDTO>>(cartItems);

            return Ok(cartItemDetailsDTOs);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while fetching cart items.");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet]
    [ApiExplorerSettings(IgnoreApi = true)]
    public async Task<IActionResult> Get()
    {
        try
        {
            var cartItems = await _cartItemRepository.GetAllCartItemsAsync();

            var cartItemDTOs = _mapper.Map<IEnumerable<CartItemResponseDTO>>(cartItems);

            return Ok(cartItemDTOs);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while fetching all cart items.");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPut("Edit Your Cart")]
    public async Task<IActionResult> Put(int id, [FromBody] CartItemDTO cartItemRequest)
    {
        try
        {
            var existingCartItem = await _cartItemRepository.GetCartItemByIdAsync(id);
            if (existingCartItem == null)
            {
                return NotFound($"CartItem with ID {id} not found.");
            }

            var product = await _cartItemRepository.GetProductByIdAsync(cartItemRequest.ProductID);
            if (product == null)
            {
                return NotFound($"Product with ID {cartItemRequest.ProductID} not found.");
            }

            var user = await _cartItemRepository.GetUserByIdAsync(cartItemRequest.UserID);
            if (user == null)
            {
                return NotFound($"User with ID {cartItemRequest.UserID} not found.");
            }

            _mapper.Map(cartItemRequest, existingCartItem);
            existingCartItem.TotalPrice = cartItemRequest.Quantity * product.Price;

            await _cartItemRepository.UpdateCartItemAsync(existingCartItem);

            return Ok(existingCartItem);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while editing the cart item.");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpDelete("Delete the Cart")]
    public async Task<IActionResult> Delete(int id)
    {
        try
        {
            var cartItem = await _cartItemRepository.GetCartItemByIdAsync(id);
            if (cartItem == null)
            {
                return NotFound($"CartItem with ID {id} not found.");
            }

            await _cartItemRepository.DeleteCartItemAsync(id);

            return Ok("Deleted Successfully!");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while deleting the cart item.");
            return StatusCode(500, "Internal server error");
        }
    }
}
