﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<UserController> _logger;

        public UserController(IUserRepository userRepository, IMapper mapper, ILogger<UserController> logger)
        {
            _userRepository = userRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [Authorize(Roles = "Admin,User")]
        [HttpGet("User Account")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var user = await _userRepository.GetUserByIdAsync(id);
                if (user == null)
                {
                    return NotFound($"User with ID {id} not found.");
                }

                var userDTO = _mapper.Map<UserDTO>(user);

                return Ok(userDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching the user by ID {UserID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "User")]
        [HttpPut("Edit Account")]
        public async Task<IActionResult> Update(int id, [FromBody] UserDTO userRequest)
        {
            try
            {
                var existingUser = await _userRepository.GetUserByIdAsync(id);
                if (existingUser == null)
                {
                    return NotFound($"User with ID {id} not found.");
                }

                _mapper.Map(userRequest, existingUser);

                await _userRepository.UpdateUserAsync(existingUser);

                return Ok(existingUser);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating the user account with ID {UserID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "Admin,User")]
        [HttpDelete("Delete Account")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var user = await _userRepository.GetUserByIdAsync(id);
                if (user == null)
                {
                    return NotFound($"User with ID {id} not found.");
                }

                await _userRepository.DeleteUserAsync(id);

                return Ok("Deleted Successfully!");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the user account with ID {UserID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
