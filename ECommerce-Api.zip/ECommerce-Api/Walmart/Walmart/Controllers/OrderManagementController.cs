﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderManagementController : ControllerBase
    {
        private readonly IOrderManagementRepository _orderManagementRepository;
        private readonly IUserRepository _userRepository;
        private readonly IProductManagementRepository _productManagementRepository;
        private readonly ICartItemRepository _cartItemRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<OrderManagementController> _logger;

        public OrderManagementController(
            IOrderManagementRepository orderManagementRepository,
            IUserRepository userRepository,
            IProductManagementRepository productManagementRepository,
            ICartItemRepository cartItemRepository,
            IMapper mapper,
            ILogger<OrderManagementController> logger)
        {
            _orderManagementRepository = orderManagementRepository;
            _userRepository = userRepository;
            _productManagementRepository = productManagementRepository;
            _cartItemRepository = cartItemRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [Authorize(Roles = "User")]
        [HttpPost("Order Now")]
        public async Task<IActionResult> Post([FromBody] OrderManagementDTO orderRequest)
        {
            try
            {
                var product = await _orderManagementRepository.GetProductByIdAsync(orderRequest.ProductID);
                if (product == null)
                {
                    return NotFound($"Product with ID {orderRequest.ProductID} not found.");
                }

                var user = await _orderManagementRepository.GetUserByIdAsync(orderRequest.UserID);
                if (user == null)
                {
                    return NotFound($"User with ID {orderRequest.UserID} not found.");
                }

                var order = _mapper.Map<OrderManagement>(orderRequest);
                order.TotalPrice = orderRequest.Quantity * product.Price;
                order.ProductManagement = product;
                order.User = user;

                await _orderManagementRepository.AddOrderAsync(order);

                var orderResponse = _mapper.Map<OrderManagementDTO>(order);

                return CreatedAtAction(nameof(GetOrder), new { id = order.OrderID }, orderResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while placing an order.");
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "User")]
        [HttpPost("Checkout From Cart")]
        public async Task<IActionResult> CheckoutCartByCartId(int cartId, [FromBody] Checkout checkoutRequest)
        {
            try
            {
                var cartItem = await _cartItemRepository.GetCartItemByIdAsync(cartId);
                if (cartItem == null)
                {
                    return NotFound($"Cart item with ID {cartId} not found.");
                }

                var product = await _cartItemRepository.GetProductByIdAsync(cartItem.ProductID);
                if (product == null)
                {
                    return NotFound($"Product with ID {cartItem.ProductID} not found.");
                }

                var user = await _cartItemRepository.GetUserByIdAsync(cartItem.UserID);
                if (user == null)
                {
                    return NotFound($"User with ID {cartItem.UserID} not found.");
                }

                var totalPrice = cartItem.Quantity * product.Price;

                var order = new OrderManagement
                {
                    UserID = cartItem.UserID,
                    ProductID = cartItem.ProductID,
                    Quantity = cartItem.Quantity,
                    TotalPrice = totalPrice,
                    ShippingAddress = checkoutRequest.ShippingAddress,
                    OrderStatus = "Placed",
                    PaymentStatus = checkoutRequest.PaymentMode,
                    ProductManagement = product,
                    User = user
                };

                await _orderManagementRepository.AddOrderAsync(order);
                await _cartItemRepository.DeleteCartItemAsync(cartItem.CartItemID);

                var orderResponse = _mapper.Map<OrderManagementDTO>(order);

                return CreatedAtAction(nameof(GetOrder), new { id = order.OrderID }, orderResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during checkout from cart.");
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "User")]
        [HttpGet("Your Orders")]
        public async Task<IActionResult> GetOrdersByUserId(int userId)
        {
            try
            {
                var orders = await _orderManagementRepository.GetAllOrdersAsync();
                var userOrders = orders.Where(o => o.UserID == userId).ToList();

                if (!userOrders.Any())
                {
                    return NotFound($"No orders found for User ID {userId}.");
                }

                var orderDTOs = _mapper.Map<IEnumerable<OrderManagementDTO>>(userOrders);

                return Ok(orderDTOs);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving orders for User ID {UserID}.", userId);
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "Admin,User")]
        [HttpGet("Order Details")]
        public async Task<ActionResult<OrderManagementDTO>> GetOrder(int id)
        {
            try
            {
                var order = await _orderManagementRepository.GetOrderByIdAsync(id);
                if (order == null)
                {
                    return NotFound($"Order with ID {id} not found.");
                }

                var orderDTO = _mapper.Map<OrderManagementDTO>(order);

                return Ok(orderDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving order details for Order ID {OrderID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "Admin,User")]
        [HttpPut("Edit Order")]
        public async Task<IActionResult> UpdateOrderStatus(int id, [FromBody] OrderManagementDTO orderRequest)
        {
            try
            {
                var existingOrder = await _orderManagementRepository.GetOrderByIdAsync(id);
                if (existingOrder == null)
                {
                    return NotFound($"Order with ID {id} not found.");
                }

                var product = await _productManagementRepository.GetProductByIdAsync(orderRequest.ProductID);
                if (product == null)
                {
                    return NotFound($"Product with ID {orderRequest.ProductID} not found.");
                }

                _mapper.Map(orderRequest, existingOrder);
                existingOrder.TotalPrice = orderRequest.Quantity * product.Price;

                await _orderManagementRepository.UpdateOrderAsync(existingOrder);

                return Ok(existingOrder);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating the order status for Order ID {OrderID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("Delete the Order")]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            try
            {
                var order = await _orderManagementRepository.GetOrderByIdAsync(id);
                if (order == null)
                {
                    return NotFound($"Order with ID {id} not found.");
                }

                await _orderManagementRepository.DeleteOrderAsync(id);

                return Ok("Deleted Successfully!");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the order with ID {OrderID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
