﻿using Walmart.Models.Domain;
using Walmart.Repositories.Interface;
using System.Collections.Generic;
using System.Threading.Tasks;
using Walmart.Models.Domain;

namespace Walmart.Repositories.Interface
{
    public interface IProductManagementRepository
    {
        Task<IEnumerable<ProductManagement>> GetAllProductsAsync();
        Task<ProductManagement> GetProductByIdAsync(int id);
        Task<ProductManagement> GetProductByNameAsync(string Name);
        Task AddProductAsync(ProductManagement product);
        Task UpdateProductAsync(ProductManagement product);
        Task DeleteProductAsync(int id);
    }
}