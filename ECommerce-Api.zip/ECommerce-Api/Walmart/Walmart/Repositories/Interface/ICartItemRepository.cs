﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Walmart.Models.Domain;

namespace Walmart.Repositories.Interface
{
    public interface ICartItemRepository
    {
        Task<IEnumerable<CartItem>> GetAllCartItemsAsync();
        Task<CartItem> GetCartItemByIdAsync(int id);
        Task<ProductManagement> GetProductByIdAsync(int id);
        Task<User> GetUserByIdAsync(int id);
        Task AddCartItemAsync(CartItem cartItem);
        Task UpdateCartItemAsync(CartItem cartItem);
        Task DeleteCartItemAsync(int id);
        Task<IEnumerable<CartItem>> GetCartItemsByUserIdAsync(int userId);
        //Task<IEnumerable<CartItem>> GetCartItemsByUserIdAsync(int userId);
        //Task DeleteCartItemAsync(int id);
    }
}