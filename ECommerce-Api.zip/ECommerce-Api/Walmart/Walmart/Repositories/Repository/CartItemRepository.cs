﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Walmart.Data;
using Walmart.Models.Domain;
using Walmart.Repositories.Interface;

namespace Walmart.Repositories.Repository
{
    public class CartItemRepository : ICartItemRepository
    {
        private readonly HeroDbContext _dbContext;

        public CartItemRepository(HeroDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<CartItem>> GetAllCartItemsAsync()
        {
            return await _dbContext.CartItems
                .Include(c => c.ProductManagement)
                .Include(c => c.User)
                .ToListAsync();
        }
        public async Task<IEnumerable<CartItem>> GetCartItemsByUserIdAsync(int userId)
        {
            return await _dbContext.CartItems
        .Include(c => c.ProductManagement)
        .Include(c => c.User)
        .Where(c => c.UserID == userId)
        .ToListAsync();
        }

        public async Task<CartItem> GetCartItemByIdAsync(int id)
        {
            return await _dbContext.CartItems
                .Include(c => c.ProductManagement)
                .Include(c => c.User)
                .FirstOrDefaultAsync(c => c.CartItemID == id);
        }

        public async Task AddCartItemAsync(CartItem cartItem)
        {
            await _dbContext.CartItems.AddAsync(cartItem);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<ProductManagement> GetProductByIdAsync(int id)
        {
            return await _dbContext.ProductManagements.FindAsync(id);
        }

        public async Task<User> GetUserByIdAsync(int id)
        {
            return await _dbContext.Users.FindAsync(id);
        }

        public async Task UpdateCartItemAsync(CartItem cartItem)
        {
            _dbContext.CartItems.Update(cartItem);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteCartItemAsync(int id)
        {
            var cartItem = await _dbContext.CartItems.FindAsync(id);
            if (cartItem != null)
            {
                _dbContext.CartItems.Remove(cartItem);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}