﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Walmart.Data;
using Walmart.Models.Domain;
using Walmart.Repositories.Interface;

namespace Walmart.Repositories.Repository
{
    public class OrderManagementRepository : IOrderManagementRepository
    {
        private readonly HeroDbContext _dbContext;

        public OrderManagementRepository(HeroDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<OrderManagement>> GetAllOrdersAsync()
        {
            return await _dbContext.OrderManagements
                .Include(o => o.User)
                .Include(o => o.ProductManagement)
                .ToListAsync();
        }

        public async Task<OrderManagement> GetOrderByIdAsync(int id)
        {
            return await _dbContext.OrderManagements
                .Include(o => o.User)
                .Include(o => o.ProductManagement)
                .FirstOrDefaultAsync(o => o.OrderID == id);
        }
        public async Task<ProductManagement> GetProductByIdAsync(int id)
        {
            return await _dbContext.ProductManagements.FindAsync(id);
        }

        public async Task<User> GetUserByIdAsync(int id)
        {
            return await _dbContext.Users.FindAsync(id);
        }

        public async Task AddOrderAsync(OrderManagement order)
        {
            await _dbContext.OrderManagements.AddAsync(order);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateOrderAsync(OrderManagement order)
        {
            _dbContext.OrderManagements.Update(order);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteOrderAsync(int id)
        {
            var order = await _dbContext.OrderManagements.FindAsync(id);
            if (order != null)
            {
                _dbContext.OrderManagements.Remove(order);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}