﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Walmart.Models.Domain
{
    public class CartItem
    {
        [Key]
        public int CartItemID { get; set; }
        [ForeignKey("User")]
        public int UserID { get; set; }
        [ForeignKey("ProductManagement")]
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public ProductManagement ProductManagement { get; set; } = new ProductManagement();
        public User User { get; set; } = new User();
    }
}

