﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Walmart.Migrations
{
    /// <inheritdoc />
    public partial class fdghjk : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OrderItem",
                columns: table => new
                {
                    OrderItemID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductID = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ProductManagementProductId = table.Column<int>(type: "int", nullable: false),
                    OrderManagementOrderID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderItem", x => x.OrderItemID);
                    table.ForeignKey(
                        name: "FK_OrderItem_OrderManagements_OrderManagementOrderID",
                        column: x => x.OrderManagementOrderID,
                        principalTable: "OrderManagements",
                        principalColumn: "OrderID");
                    table.ForeignKey(
                        name: "FK_OrderItem_ProductManagements_ProductManagementProductId",
                        column: x => x.ProductManagementProductId,
                        principalTable: "ProductManagements",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OrderItem_OrderManagementOrderID",
                table: "OrderItem",
                column: "OrderManagementOrderID");

            migrationBuilder.CreateIndex(
                name: "IX_OrderItem_ProductManagementProductId",
                table: "OrderItem",
                column: "ProductManagementProductId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderItem");
        }
    }
}
