﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Walmart.Data;
using Walmart.Models.Domain;
using Walmart.Repositories.Interface;

namespace Walmart.Repositories.Repository
{
    public class ProductManagementRepository : IProductManagementRepository
    {
        private readonly HeroDbContext _dbContext;

        public ProductManagementRepository(HeroDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<ProductManagement>> GetAllProductsAsync()
        {
            return await _dbContext.ProductManagements.ToListAsync();
        }

        public async Task<ProductManagement> GetProductByIdAsync(int id)
        {
            return await _dbContext.ProductManagements.FindAsync(id);
        }
        public async Task<ProductManagement> GetProductByNameAsync (string Name)
        {
            return await _dbContext.ProductManagements.FirstOrDefaultAsync(p => p.Name == Name);
        }
        public async Task AddProductAsync(ProductManagement product)
        {
            await _dbContext.ProductManagements.AddAsync(product);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateProductAsync(ProductManagement product)
        {
            _dbContext.ProductManagements.Update(product);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteProductAsync(int id)
        {
            var product = await _dbContext.ProductManagements.FindAsync(id);
            if (product != null)
            {
                _dbContext.ProductManagements.Remove(product);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}