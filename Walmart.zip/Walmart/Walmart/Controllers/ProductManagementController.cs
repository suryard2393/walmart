﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductManagementController : ControllerBase
    {
        private readonly IProductManagementRepository _productManagementRepository;
        private readonly IMapper _mapper;

        public ProductManagementController(IProductManagementRepository productManagementRepository, IMapper mapper)
        {
            _productManagementRepository = productManagementRepository;
            _mapper = mapper;
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("Add Products")]
        public async Task<IActionResult> Create([FromBody] ProductManagementDTO productManagementRequest)
        {
            // Map DTO to Domain Model
            var newProduct = _mapper.Map<ProductManagement>(productManagementRequest);

            await _productManagementRepository.AddProductAsync(newProduct);

            // Map Domain Model back to DTO for the response
            var productResponse = _mapper.Map<ProductManagementDTO>(newProduct);

            return CreatedAtAction(nameof(GetById), new { id = newProduct.ProductId }, productResponse);
        }

        [Authorize(Roles = "User,Admin")]
        [HttpGet("Search The Product")]
        public async Task<IActionResult> GetById(int id)
        {
            var product = await _productManagementRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound($"Product with ID {id} not found.");
            }

            // Map Domain Model to DTO
            var productDTO = _mapper.Map<ProductManagementDTO>(product);

            return Ok(productDTO);
        }
        [HttpGet("Search By Name")]
        public async Task<IActionResult> GetByName(string Name)
        {
            var product = await _productManagementRepository.GetProductByNameAsync(Name);
            if (product == null)
            {
                return NotFound("Product with name {Name} not found.");
            }
            var productDTO = _mapper.Map<ProductManagementDTO>(product);

            return Ok(productDTO);
        }

        [Authorize(Roles = "User,Admin")]
        [HttpGet("All Products")]
        public async Task<IActionResult> GetAll()
        {
            var products = await _productManagementRepository.GetAllProductsAsync();

            // Map list of Domain Models to list of DTOs
            var productDTOs = _mapper.Map<IEnumerable<ProductManagementDTO>>(products);

            return Ok(productDTOs);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("Edit Product")]
        public async Task<IActionResult> Update(int id, [FromBody] ProductManagementDTO productManagementRequest)
        {
            var existingProduct = await _productManagementRepository.GetProductByIdAsync(id);
            if (existingProduct == null)
            {
                return NotFound($"Product with ID {id} not found.");
            }

            // Map updated values from DTO to existing Domain Model
            _mapper.Map(productManagementRequest, existingProduct);

            await _productManagementRepository.UpdateProductAsync(existingProduct);

            return Ok(existingProduct);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("Delete Product")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _productManagementRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound($"Product with ID {id} not found.");
            }

            await _productManagementRepository.DeleteProductAsync(id);

            return Ok("Deleted Successfully!");
        }
    }
}
