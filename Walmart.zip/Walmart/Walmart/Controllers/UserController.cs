﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;

        public UserController(IUserRepository userRepository, IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }

        [Authorize(Roles = "Admin,User")]
        [HttpGet("User Account")]
        public async Task<IActionResult> GetById(int id)
        {
            var user = await _userRepository.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound($"User with ID {id} not found.");
            }

            // Map User to UserDTO
            var userDTO = _mapper.Map<UserDTO>(user);

            return Ok(userDTO);
        }

        [Authorize(Roles = "User")]
        [HttpPut("Edit Account")]
        public async Task<IActionResult> Update(int id, [FromBody] UserDTO userRequest)
        {
            var existingUser = await _userRepository.GetUserByIdAsync(id);
            if (existingUser == null)
            {
                return NotFound($"User with ID {id} not found.");
            }

            // Map updated values from UserDTO to the existing User domain model
            _mapper.Map(userRequest, existingUser);

            await _userRepository.UpdateUserAsync(existingUser);

            return Ok(existingUser);
        }

        [Authorize(Roles = "Admin,User")]
        [HttpDelete("Delete Account")]
        public async Task<IActionResult> Delete(int id)
        {
            var user = await _userRepository.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound($"User with ID {id} not found.");
            }

            await _userRepository.DeleteUserAsync(id);

            return Ok("Deleted Successfully!");
        }
    }
}
