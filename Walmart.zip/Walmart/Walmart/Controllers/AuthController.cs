﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Walmart.Helpers;
using Walmart.Models.Domain;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IAdminRepository _adminRepository;
        private readonly JwtHelper _jwtHelper;
        private readonly IMapper _mapper;

        public AuthController(
            IUserRepository userRepository,
            IAdminRepository adminRepository,
            JwtHelper jwtHelper,
            IMapper mapper)
        {
            _userRepository = userRepository;
            _adminRepository = adminRepository;
            _jwtHelper = jwtHelper;
            _mapper = mapper;
        }

        [HttpPost("User Registration")]
        public async Task<IActionResult> RegisterUser([FromBody] RegisterDTO registerDTO)
        {
            if (await _userRepository.GetUserByEmailAsync(registerDTO.Email) != null)
                return BadRequest("User already exists");

            // Use AutoMapper to map RegisterDTO to User
            var user = _mapper.Map<User>(registerDTO);
            user.Role = "User"; // Assign the role explicitly

            await _userRepository.AddUserAsync(user);
            return Ok("User registered successfully");
        }

        [HttpPost("Admin Registration")]
        public async Task<IActionResult> RegisterAdmin([FromBody] RegisterDTO registerDTO)
        {
            if (await _adminRepository.GetAdminByEmailAsync(registerDTO.Email) != null)
                return BadRequest("Admin already exists");

            // Use AutoMapper to map RegisterDTO to Admin
            var admin = _mapper.Map<Admin>(registerDTO);
            admin.Role = "Admin"; // Assign the role explicitly

            await _adminRepository.AddAdminAsync(admin);
            return Ok("Admin registered successfully");
        }

        [HttpPost("User Login")]
        public async Task<IActionResult> UserLogin([FromBody] LoginDTO loginDTO)
        {
            var user = await _userRepository.GetUserByEmailAsync(loginDTO.Email);
            if (user == null || user.Password != loginDTO.Password)
            {
                return Unauthorized("Invalid credentials");
            }

            var token = _jwtHelper.GenerateToken(user.UserID, user.Email, user.Role);
            return Ok(new { Token = token });
        }

        [HttpPost("Admin Login")]
        public async Task<IActionResult> AdminLogin([FromBody] LoginDTO loginDTO)
        {
            var admin = await _adminRepository.GetAdminByEmailAsync(loginDTO.Email);
            if (admin == null || admin.Password != loginDTO.Password)
            {
                return Unauthorized("Invalid credentials");
            }

            var token = _jwtHelper.GenerateToken(admin.AdminID, admin.Email, admin.Role);
            return Ok(new { Token = token });
        }
    }
}