﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;

[Route("api/[controller]")]
[ApiController]
[Authorize(Roles = "User")]
public class CartItemController : ControllerBase
{
    private readonly ICartItemRepository _cartItemRepository;
    private readonly IMapper _mapper;

    public CartItemController(ICartItemRepository cartItemRepository, IMapper mapper)
    {
        _cartItemRepository = cartItemRepository;
        _mapper = mapper;
    }

    [HttpPost("Add Into Cart")]
    public async Task<IActionResult> Post([FromBody] CartItemDTO cartItemRequest)
    {
        var product = await _cartItemRepository.GetProductByIdAsync(cartItemRequest.ProductID);
        if (product == null)
        {
            return NotFound($"Product with ID {cartItemRequest.ProductID} not found.");
        }

        var user = await _cartItemRepository.GetUserByIdAsync(cartItemRequest.UserID);
        if (user == null)
        {
            return NotFound($"User with ID {cartItemRequest.UserID} not found.");
        }

        var totalPrice = cartItemRequest.Quantity * product.Price;

        // Map CartItemDTO to CartItem and set calculated values
        var cartItem = _mapper.Map<CartItem>(cartItemRequest);
        cartItem.TotalPrice = totalPrice;
        cartItem.ProductManagement = product;
        cartItem.User = user;

        await _cartItemRepository.AddCartItemAsync(cartItem);

        // Map CartItem to CartItemResponseDTO for the response
        var cartItemResponse = _mapper.Map<CartItemResponseDTO>(cartItem);

        return CreatedAtAction(nameof(Get), new { id = cartItem.CartItemID }, cartItemResponse);
    }

    [HttpGet("Your Cart")]
    public async Task<IActionResult> GetByUserId(int userId)
    {
        var cartItems = await _cartItemRepository.GetCartItemsByUserIdAsync(userId);
        if (cartItems == null || !cartItems.Any())
        {
            return NotFound($"No cart items found for User ID {userId}.");
        }

        // Map list of CartItems to CartItemDetailsDTOs
        var cartItemDetailsDTOs = _mapper.Map<IEnumerable<CartItemDetailsDTO>>(cartItems);

        return Ok(cartItemDetailsDTOs);
    }

    [HttpGet]
    [ApiExplorerSettings(IgnoreApi = true)]
    public async Task<IActionResult> Get()
    {
        var cartItems = await _cartItemRepository.GetAllCartItemsAsync();

        // Map list of CartItems to CartItemResponseDTOs
        var cartItemDTOs = _mapper.Map<IEnumerable<CartItemResponseDTO>>(cartItems);

        return Ok(cartItemDTOs);
    }

    [HttpPut("Edit Your Cart")]
    public async Task<IActionResult> Put(int id, [FromBody] CartItemDTO cartItemRequest)
    {
        var existingCartItem = await _cartItemRepository.GetCartItemByIdAsync(id);
        if (existingCartItem == null)
        {
            return NotFound($"CartItem with ID {id} not found.");
        }

        var product = await _cartItemRepository.GetProductByIdAsync(cartItemRequest.ProductID);
        if (product == null)
        {
            return NotFound($"Product with ID {cartItemRequest.ProductID} not found.");
        }

        var user = await _cartItemRepository.GetUserByIdAsync(cartItemRequest.UserID);
        if (user == null)
        {
            return NotFound($"User with ID {cartItemRequest.UserID} not found.");
        }

        // Update the existing CartItem with values from DTO and calculated values
        _mapper.Map(cartItemRequest, existingCartItem);
        existingCartItem.TotalPrice = cartItemRequest.Quantity * product.Price;

        await _cartItemRepository.UpdateCartItemAsync(existingCartItem);

        return Ok(existingCartItem);
    }

    [HttpDelete("Delete the Cart")]
    public async Task<IActionResult> Delete(int id)
    {
        var cartItem = await _cartItemRepository.GetCartItemByIdAsync(id);
        if (cartItem == null)
        {
            return NotFound($"CartItem with ID {id} not found.");
        }

        await _cartItemRepository.DeleteCartItemAsync(id);

        return Ok("Deleted Successfully!");
    }
}
